function top100(value) {
    console.log('top100');
}

export default top100;